#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <unistd.h>
#include <iostream>

int main()
{
  int t1, i, t2, poolsz ,  fd, count;
  char *p ;char *q ;
  q= "abcdefgh";
  t1 = 2;
  t2 = 1;
   poolsz =262144;
   count = 3;

   if ((fd = open("/proc/self/status", 0)) < 0) {

    return -2;
  }

  if (!( p = malloc(poolsz))) { return -4; }

  if ((i=read(fd, p, poolsz )) <= 0) {

    return -3;
  }


  close(fd);

  fopen("/proc/self/maps", "r");
  popen("cat /proc/sys/kernel/random/boot_id", "r");
  
	return count;

}